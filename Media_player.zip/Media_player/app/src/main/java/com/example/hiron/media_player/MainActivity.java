package com.example.hiron.media_player;



import android.os.Environment;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.example.hiron.media_player.R;
import com.google.android.material.bottomappbar.BottomAppBar;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.io.File;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    ListView lv;
    BottomAppBar appBar;
    FloatingActionButton btn;
    String[] items;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
      lv=(ListView)findViewById(R.id.lv);
      appBar=(BottomAppBar)findViewById(R.id.appbar);
      btn=(FloatingActionButton)findViewById(R.id.fbtn);
      ArrayList<File> mysongs=FetchSong(Environment.getExternalStorageDirectory());

      for (int i=0;i<mysongs.size();i++){
          items[i]=mysongs.get(i).toString();
      }
          ArrayAdapter songadapter=new ArrayAdapter(getApplicationContext(),R.layout.playlist,items);
      lv.setAdapter(songadapter);
    }
//fatching files
    public ArrayList<File> FetchSong(File root){
        ArrayList<File> song=new ArrayList<File>();
        File[] files=root.listFiles();
        for(File singlefile:files){
            if(singlefile.isDirectory()&&!singlefile.isHidden()){
                song.addAll(FetchSong(singlefile));

            }
            else{
                if(singlefile.getName().endsWith(".mp3")||singlefile.getName().endsWith(".wav")){
                    song.add(singlefile);
                }
            }
        }
        return song;
    }

}
